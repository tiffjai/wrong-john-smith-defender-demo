# Wrong John Smith Defender — Track 3 synthetic screening demo (milestone 1)

**Synthetic data only.** Every person, name, date, ID, place and source is fictional. The dashboard supports an
analyst; the analyst makes the final screening decision. Nothing here is published or networked: the app makes no
network calls at runtime (network is needed only for the one-off `pip install`).

## Launch (one command)

```bash
./run.sh            # creates .venv, installs pinned deps, starts http://127.0.0.1:8501
```

Other commands: `./run.sh test` (pytest), `./run.sh evaluate`, `./run.sh export`, `./run.sh check`
(headless start + `/_stcore/health` + page probe, then stop). Deep link to a case: `/?case=CASE-08`.
Needs Python ≥ 3.11 (tested on 3.13.5, Linux x86_64). Pins: `requirements.txt` (runtime), `requirements-dev.txt` (+pytest).

## Scenarios (3 of the brief's cases)

| Case | Brief | Records | Candidate pairs |
|---|---|---|---|
| CASE-01 (#01) | same-name decoy, conflicting **verified full** DOBs | A, B | A–B |
| CASE-03 (#03) | plausible match via a **sourced Cantonese/Pinyin alias** (`ALIAS-0001`, source `SRC-SYN-ALIAS-001`) | A "Wong Siu Ming", B "Huang Xiaoming" (DOB `Jul 1988`, unverified) | A–B (found only via the alias block) |
| CASE-08 (#08) | misleading chain; A and C have contradictory verified full DOBs | A, B (DOB unknown), C | A–B, B–C and the direct A–C comparison |

The scenario names/titles live only in `evaluation/labels.json` (shown in the dashboard's Evaluation tab behind a toggle),
not in the data, the scoring code or the packets.

## How it works

```
data/records.json + data/alias_table.json
        │ defender/data.py (normalise; raw values kept; unknown stays None)
        ▼
 candidate pairs  (blocking: same case & same family name  OR  same case & same documented alias group)
        │  generated once in Python and cross-checked against Splink's own blocked pairs (error on any difference)
        ├──► 1 name-only   RapidFuzz token_sort_ratio on normalised full name     → LINK / REVIEW / NO_LINK
        ├──► 2 Splink 4 (DuckDB): name, dob, country, city comparisons             → LINK / REVIEW / NO_LINK
        └──► 3 Splink + deterministic guard (defender/guard.py)                    → may escalate to REVIEW
```

* **Splink without EM.** With 5 synthetic pairs, EM training is unstable and would just fit noise. All m/u
  probabilities, the prior (0.01) and the thresholds are fixed in `config/draft_config.json` and frozen. Splink is used
  as the scoring engine (blocking, comparison levels, Bayes factors, match weights). They are builder-chosen
  illustrative values, **not fitted or validated**; the test suite checks that each Splink Bayes factor equals m/u of the chosen level and that the
  probability recomputes from the contributions.
* **DOB comparison respects precision.** Levels: full exact / year+month agree (a date lacks its day) / year agrees (a date lacks its month) /
  differ at the shared precision; unknown on either side → neutral level (BF = 1). Splink does not see verification status.
* **Guard.** Contradiction = both DOBs **full precision and verified** and different. Partial, unverified, unknown or
  unparseable dates are `not_assessable` — never a contradiction, never imputed. Guard escalates LINK/REVIEW pairs with a direct
  contradiction to REVIEW, and also chain-checks: records joined by Splink LINK edges form a component; if any pair in
  it contradicts, every pair in the component goes to REVIEW (that is how A–B and B–C in CASE-08 are caught even though neither
  has a direct contradiction). The guard never hides a pair or lowers a score.
* **Alias.** Aliases come only from `data/alias_table.json`; an entry without a `source_id` is rejected. An alias gives a candidate and a strong
  name level, but cannot override a contradiction.
* **Frozen thresholds.** `python scripts/freeze_config.py` writes `config/frozen_config.json` (`frozen_at` + `config_sha256`
  over parameters and the SHA-256 of the records/alias inputs). Pipeline and evaluation call `load_frozen()` and raise
  if anything changed after freezing. Evaluation records `frozen_at`, `evaluated_at`, and the config hash with its results.
* **Labels are separate.** `evaluation/labels.json` is read only by `evaluation/evaluate.py` (and the dashboard's Evaluation tab).
  Nothing in `defender/` imports or opens it (static + dynamic tests), and packets contain no label keys/values (test).

## Dashboard

Case selector (sidebar) → raw records table (raw values, normalised DOB, date precision, verification status/method/source, source IDs) →
three columns over the **same** pairs → chain view (CASE-08) → per-pair evidence (name-only score, Splink field contributions with m/u/BF/weight,
guard check) → analyst review (Undecided / Confirm match / Not a match / Escalate + note; saved to `reviews/analyst_reviews.json`,
not into packets) → JSON evidence packet download. Evaluation tab: FP, missed true matches, manual-review pairs, candidate recall, each as n/d per method.
Method tab: frozen parameters and the alias table.

## Evidence packet (`exports/evidence_packet_<CASE>.json`)

`case_id`, `records[]` (source id/name/type, per-field `evidence_id`, `raw_value`, `normalised_value`, `date_precision`, `verification`),
`candidate_pairs[]` (blocking rules, alias evidence with source id, name-only score, Splink weight/probability + `field_contributions[]`
with pair evidence IDs, guard outcome/reasons/DOB check), `chain_analysis`, `case_outcome`, and `model` (frozen parameters + hash so a reviewer can recompute).
Evidence IDs are `EV-` + first 12 hex of SHA-256 over `[record_id, source_id, field, raw_value]`, so they are stable across runs. The packet has no timestamps, so
regeneration is byte-identical (tested). No evaluation labels.

## Measured counts (this milestone; 5 candidate pairs, 2 labelled true matches, 3 labelled non-matches)

| Method | False positives (auto-linked non-matches) | Missed true matches | Manual-review pairs | Candidate recall |
|---|---|---|---|---|
| Name-only (RapidFuzz) | 3/3 | 1/2 | 0/5 | 2/2 |
| Splink | 2/3 | 0/2 | 0/5 | 2/2 |
| Splink + guard | 0/3 | 0/2 | 4/5 | 2/2 |

Without the alias table: 4 candidate pairs, candidate recall 1/2 (CASE-03 is never generated). Full output in `verification/`.
These numbers show the pipeline working on hand-built scenarios; they are **not** evidence of real-world accuracy.

## Limitations

* Three hand-built scenarios; parameters were chosen by the builder who knew them (no held-out data). Thresholds are frozen *before the evaluation run*, but not tuned on independent data.
* Candidate generation is scoped to a case (records are only compared inside their case) and uses family-name / alias blocking only.
* The guard is DOB-only. Other verified identifiers (IDs, nationality) are out of scope for this milestone.
* `DD/MM/YYYY` raw dates are parsed day-first (documented assumption).
* The analyst review store is a local JSON file, single user, no authentication.
* Scenarios #02, #04–#07 and #09+ of the brief are not implemented yet.
